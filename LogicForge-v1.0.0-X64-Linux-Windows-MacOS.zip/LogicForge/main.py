# main.py
"""
Main entry point for the Dynamic Project Builder Utility.
Launches the Tkinter GUI.
"""

from ui.gui import App

if __name__ == "__main__":
    app = App()
    app.mainloop()