# cli_core.py
"""
Core Backend Logic and API Definition for the Project Builder Utility.
This script contains the engine that executes build scripts. It delegates
complex tasks like compilation to specialized modules.
"""
"""
# =================================================================================
# AI GUIDE & API REFERENCE FOR `PROJECT BUILDER` (v5.1)
# =================================================================================

# YOUR ROLE:
# You are an expert AI code generator. Your task is to write a Python script,
# called a "blueprint," based on a user's request. This blueprint will be executed
# by a special environment, and you MUST ONLY use the functions and variables
# defined in this guide.

# YOUR PRIMARY OBJECTIVE:
# Your entire output MUST be a single, raw Python script. DO NOT add any
# surrounding text, explanations, or markdown code fences (e.g., ```python).

# =================================================================================
# SECTION 1: HOW TO WRITE A BLUEPRINT (WORKFLOW)
# =================================================================================

# A professional blueprint follows a strict, three-stage process. ALWAYS structure
# your generated scripts in this order for safety and clarity.

# STAGE 1: PRE-FLIGHT CHECKS
# Verify the user's environment is ready before creating any files.
# 1. Use `require_tool()` for every essential command-line program.
# 2. Use `ensure_dependencies()` for all language-specific packages.

# STAGE 2: PROJECT SCAFFOLDING
# Create the project's file structure.
# 1. Call `create_project_folder()` to establish the root directory.
# 2. Call `create_file()` for every source code file, config file, etc.

# STAGE 3: POST-BUILD ACTIONS & COMPILATION
# After all files have been created, perform final actions.
# 1. Use the `compile_project()` function for standard compilation.
# 2. Use the OS Dev API (`pad_bootsector`, `concatenate_files`) for low-level tasks.
# 3. Use `run_command()` for other tasks like `git init` or running emulators.

# =================================================================================
# SECTION 2: API FUNCTION REFERENCE
# =================================================================================

# --- OS Development API (NEW & EXPERT) ---
# * pad_bootsector(path: str)
#   - Pads a binary file to 512 bytes and adds the 0xAA55 boot signature.
# * concatenate_files(output_path: str, file_paths: list)
#   - Joins multiple binary files into one (e.g., bootloader + kernel).

# --- Compilation API (PREFERRED) ---
# * compile_project(language: str, source_files: list, output_name: str, ...)
#   - High-level, cross-platform compiler for 'c', 'cpp', 'java'.

# --- File System API ---
# * create_project_folder(name: str)
# * create_file(path: str, content: str or bytes)
# * read_file(path: str, mode: str = 'r') -> str or bytes

# --- Environment & Dependency API ---
# * require_tool(tool_name: str)
# * ensure_dependencies(manager: str, dependencies: list, cwd: str)

# --- Command Execution API ---
# * run_command(command_list: list, cwd: str = None, env: dict = None)

# --- Dynamic Logic API ---
# * run_python_code(code_snippet: str)

# --- Utility Variables & Functions ---
# * print(), platform, os, env

# =================================================================================
# SECTION 3: CRITICAL RULES AND RESTRICTIONS
# =================================================================================

# 1. RAW PYTHON OUTPUT ONLY.
# 2. NO `def` or `class` STATEMENTS.
# 3. NO `import` STATEMENTS.
# 4. DO NOT USE `sudo`.
# 5. STRICTLY CODE OUTPUT ONLY. DO NOT ADD ANY WORDS, NOT EVEN IN COMMENTS, UNLESS ABSOLUTELY NECESSARY FOR CLARITY.
# =================================================================================
# SECTION 4: ADVANCED EXAMPLE - OS BOOTLOADER BLUEPRINT
# =================================================================================

# This example demonstrates the use of the new OS Development API functions.

# --- STAGE 1: PRE-FLIGHT CHECKS ---
# print("--- Checking for OS Development Toolchain ---")
# require_tool("nasm")
# require_tool("qemu-system-x86_64")
# print("--- Toolchain Found. ---")

# --- STAGE 2: PROJECT SCAFFOLDING ---
# project_name = "my_bootloader"
# create_project_folder(project_name)
#
# boot_asm_content = '''
# org 0x7c00
# bits 16
# start:
#     mov ah, 0x0e
#     mov al, 'B'
#     int 0x10
#     jmp $
# '''
# create_file(f"{project_name}/boot.asm", boot_asm_content)

# --- STAGE 3: POST-BUILD ACTIONS ---
# print("\\n--- Assembling and Padding Bootloader ---")
# run_command(["nasm", "-f", "bin", "boot.asm", "-o", "boot.bin"], cwd=project_name)
#
# # Use the new, specialized function instead of complex manual padding.
# pad_bootsector(f"{project_name}/boot.bin")
#
# print("\\n--- Booting in QEMU ---")
# run_command(["qemu-system-x86_64", "boot.bin"], cwd=project_name)
# print("\\n--- Build and Emulation Complete. ---")

# =================================================================================
# PROMPT FOR THE AI (ALL LLMS READ THIS)
# =================================================================================
#
# Follow this, unless the user says otherwise they want you to make a blueprint script.
# This is a api so when they send it follow it as a api and when they say what they want you to code for the blueprint script code it.

# =================================================================================
# END OF AI GUIDE & API REFERENCE
# =================================================================================
"""

import os
import subprocess
import platform
import logging
from datetime import datetime
from shutil import which
from copy import deepcopy
import json
import compiler

# --- Custom Exception Classes for Clean Error Handling ---
class ToolMissingError(Exception):
    def __init__(self, message, command_to_run=""):
        super().__init__(message)
        self.command_to_run = command_to_run

class DependencyActionRequired(Exception):
    def __init__(self, message, command_to_run="", cwd=None):
        super().__init__(message)
        self.command_to_run = command_to_run
        self.cwd = cwd

def run_builder(script_content: str, output_callback: callable, dry_run: bool = False):
    """
    Executes a user's build script (blueprint) in a controlled environment.
    """
    
    exec_globals = {}

    # --- API Functions made available to the blueprint ---
    def _require_tool(tool_name: str):
        if which(tool_name) is not None:
            output_callback(f"✅ Tool '{tool_name}' found.")
            return
        install_command = ""
        system = platform.system()
        if system == "Linux":
            if which("apt-get"): install_command = f"sudo apt update && sudo apt install {tool_name}"
            elif which("dnf"): install_command = f"sudo dnf install {tool_name}"
            elif which("pacman"): install_command = f"sudo pacman -S {tool_name}"
        elif system == "Windows":
            if which("winget"): install_command = f"winget install {tool_name}"
            elif which("choco"): install_command = f"choco install {tool_name}"
        elif system == "Darwin":
            if which("brew"): install_command = f"brew install {tool_name}"
        raise ToolMissingError(f"Required tool '{tool_name}' not found.", command_to_run=install_command)

    def _ensure_dependencies(manager: str, dependencies: list, cwd: str = None):
        output_callback(f"\nVerifying dependencies for manager: '{manager}'...")
        _require_tool(manager)
        to_install_or_update = []
        if manager.lower() in ['pip', 'pip3']:
            try:
                proc = subprocess.run([manager, "list", "--format=json"], capture_output=True, text=True, cwd=cwd)
                installed_packages = {pkg['name'].lower(): pkg['version'] for pkg in json.loads(proc.stdout)}
            except (json.JSONDecodeError, FileNotFoundError): installed_packages = {}
            for dep in dependencies:
                if '>=' in dep: name, req_ver = dep.split('>=')
                elif '==' in dep: name, req_ver = dep.split('==')
                else: name, req_ver = dep, None
                name = name.lower()
                if name not in installed_packages: to_install_or_update.append(dep)
                elif req_ver:
                    try:
                        if tuple(map(int, installed_packages[name].split('.'))) < tuple(map(int, req_ver.split('.'))): to_install_or_update.append(dep)
                    except ValueError: to_install_or_update.append(dep)
        elif manager.lower() == 'npm': to_install_or_update = dependencies
        else: raise ValueError(f"Dependency manager '{manager}' is not supported.")
        if to_install_or_update:
            command_to_run = f"{manager} install {' '.join(to_install_or_update)}"
            if manager.lower() in ['pip', 'pip3']: command_to_run += " --upgrade"
            raise DependencyActionRequired(f"Blueprint requires packages to be installed/updated.", command_to_run=command_to_run, cwd=cwd)
        else: output_callback("✅ All dependencies are already satisfied.")

    def _create_project_folder(name: str):
        if not os.path.exists(name):
            os.makedirs(name)
            output_callback(f"Created project folder: {name}")
        else:
            output_callback(f"Warning: Directory '{name}' already exists.")
        return name

    def _create_file(path: str, content: str or bytes):
        try:
            parent_dir = os.path.dirname(path)
            if parent_dir:
                os.makedirs(parent_dir, exist_ok=True)
            mode = 'wb' if isinstance(content, bytes) else 'w'
            encoding = None if isinstance(content, bytes) else 'utf-8'
            with open(path, mode, encoding=encoding) as f:
                f.write(content)
            output_callback(f"Created file: {path}")
        except Exception as e:
            raise IOError(f"Failed to create file '{path}': {e}")

    def _read_file(path: str, mode: str = 'r'):
        output_callback(f"Reading file: {path}...")
        try:
            if mode not in ['r', 'rb']:
                raise ValueError("Invalid mode. Only 'r' (text) and 'rb' (bytes) are allowed.")
            encoding = None if mode == 'rb' else 'utf-8'
            with open(path, mode, encoding=encoding) as f:
                return f.read()
        except Exception as e:
            raise IOError(f"Failed to read file '{path}': {e}")

    def _run_command(command_list: list, cwd: str = None, env: dict = None):
        try:
            process_env = deepcopy(os.environ)
            if env:
                process_env.update(env)
            output_callback(f"\n$ {' '.join(command_list)}")
            process = subprocess.Popen(
                command_list, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, encoding='utf-8', errors='replace', cwd=cwd,
                shell=(platform.system() == "Windows"), env=process_env
            )
            for line in iter(process.stdout.readline, ''):
                output_callback(line.strip())
            rc = process.wait()
            if rc != 0:
                output_callback(f"Command failed with exit code {rc}.")
            return rc
        except Exception as e:
            raise RuntimeError(f"Failed to run command: {e}")

    def _run_python_code(code_snippet: str):
        try:
            output_callback(f"\\n--- Executing Python Snippet ---")
            exec(code_snippet, exec_globals)
            output_callback(f"--- Snippet Finished ---")
        except Exception as e:
            raise RuntimeError(f"Error in Python code snippet: {e}")
    
    def _compile_project(
        language: str,
        source_files: list,
        output_name: str,
        output_type: str = 'executable',
        include_dirs: list = None,
        library_dirs: list = None,
        libraries: list = None,
        cwd: str = None
    ):
        try:
            compiler.compile_source(
                language=language,
                source_files=source_files,
                output_name=output_name,
                run_command_func=_run_command,
                require_tool_func=_require_tool,
                output_callback_func=output_callback,
                output_type=output_type,
                include_dirs=include_dirs,
                library_dirs=library_dirs,
                libraries=libraries,
                cwd=cwd
            )
        except Exception as e:
            raise RuntimeError(f"Compilation failed: {e}")

    def _pad_bootsector(path: str):
        """
        Pads a binary file to 512 bytes and adds the 0xAA55 boot signature.
        """
        output_callback(f"\\n--- Padding Bootsector: {path} ---")
        try:
            binary_data = _read_file(path, mode='rb')
            if len(binary_data) > 510:
                raise ValueError(f"Bootsector file '{path}' is too large ({len(binary_data)} bytes).")
            padding_bytes = b'\\0' * (510 - len(binary_data))
            boot_signature = b'\\x55\\xaa'
            final_bootsector = binary_data + padding_bytes + boot_signature
            _create_file(path, final_bootsector)
            output_callback(f" > Padded to 512 bytes and added boot signature.")
        except Exception as e:
            raise RuntimeError(f"Failed to pad bootsector '{path}': {e}")

    def _concatenate_files(output_path: str, file_paths: list):
        """
        Reads multiple files in binary mode and concatenates them into a single output file.
        """
        output_callback(f"\\n--- Concatenating files into: {output_path} ---")
        try:
            with open(output_path, 'wb') as outfile:
                for in_path in file_paths:
                    output_callback(f" > Appending: {in_path}")
                    file_content = _read_file(in_path, mode='rb')
                    outfile.write(file_content)
            output_callback(f"✅ Concatenation successful.")
        except Exception as e:
            raise RuntimeError(f"Failed to concatenate files: {e}")

    # Populate the exec_globals dictionary
    exec_globals.update({
        "create_project_folder": _create_project_folder,
        "create_file": _create_file,
        "read_file": _read_file,
        "run_command": _run_command,
        "require_tool": _require_tool,
        "ensure_dependencies": _ensure_dependencies,
        "run_python_code": _run_python_code,
        "compile_project": _compile_project,
        "pad_bootsector": _pad_bootsector,
        "concatenate_files": _concatenate_files,
        "platform": platform,
        "os": os,
        "env": os.environ
    })

    # --- Execution Environment ---
    output_callback("--- Starting Project Builder ---")
    
    try:
        exec(script_content, exec_globals)
        output_callback("\n--- Builder script finished. ---")
    except Exception as e:
        if isinstance(e, (ToolMissingError, DependencyActionRequired)): raise e
        error_msg = f"\n--- ERROR in blueprint script: {e} ---"
        output_callback(error_msg)
        logging.error(f"Error during script execution: {e}", exc_info=True)

def setup_logging():
    if not os.path.exists('logs'):
        os.makedirs('logs')
    log_filename = f"logs/build_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.log"
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_filename),
        ]
    )
    logging.info("Logger initialized.")