# ui/gui.py
"""
Frontend GUI for the Project Builder Utility.
This GUI allows a user to run an AI-generated build script (a "blueprint").
It uses a background thread to run the build process, keeping the GUI responsive,
and handles interactive dialogs for missing tools and dependency confirmation.
"""
import tkinter as tk
from tkinter import scrolledtext, messagebox
import os
import cli_core
import threading
import queue
import subprocess
import json

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("AI-Powered Project Builder")
        self.geometry("800x600")
        self.log_queue = queue.Queue()
        self.create_widgets()
        cli_core.setup_logging()
        self.after(100, self.process_log_queue)
        self._update_console_widget("Application ready.")
        self._update_console_widget("Use the button below to get API context for an AI, then paste the AI's script here.")

    def create_widgets(self):
        main_frame = tk.Frame(self, padx=10, pady=10)
        main_frame.pack(fill=tk.BOTH, expand=True)

        top_frame = tk.LabelFrame(main_frame, text="1. Paste AI-Generated Build Script (Blueprint) Here", padx=5, pady=5)
        top_frame.pack(fill=tk.BOTH, expand=True)

        self.script_input = scrolledtext.ScrolledText(top_frame, height=15, undo=True)
        self.script_input.pack(fill=tk.BOTH, expand=True)

        action_frame = tk.Frame(main_frame, pady=10)
        action_frame.pack(fill=tk.X)

        self.run_button = tk.Button(action_frame, text="2. Run Builder", command=self.run_the_builder, bg="#4CAF50", fg="white", font=("Helvetica", 10, "bold"))
        self.run_button.pack(side=tk.LEFT, fill=tk.X, expand=True)

        console_frame = tk.LabelFrame(main_frame, text="Output Console", padx=5, pady=5)
        console_frame.pack(fill=tk.BOTH, expand=True)

        self.console_output = scrolledtext.ScrolledText(console_frame, height=10, state='disabled', bg="#2b2b2b", fg="#cccccc")
        self.console_output.pack(fill=tk.BOTH, expand=True)

        context_frame = tk.Frame(main_frame)
        context_frame.pack(fill=tk.X, pady=(10, 0))

        self.copy_context_button = tk.Button(context_frame, text="Copy API Context for AI", command=self.copy_context_to_clipboard, bg="#007ACC", fg="white")
        self.copy_context_button.pack(side=tk.RIGHT)

        context_label = tk.Label(context_frame, text="Need the AI to write a script? Start here ->", fg="#555555")
        context_label.pack(side=tk.RIGHT, padx=5)

    # --- THIS IS THE MISSING FUNCTION THAT HAS BEEN RESTORED ---
    def copy_context_to_clipboard(self):
        """Copies the backend API definition (cli_core.py) to the clipboard."""
        try:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            backend_path = os.path.join(current_dir, '..', 'cli_core.py')
            with open(backend_path, 'r', encoding='utf-8') as f:
                backend_code = f.read()
            
            self.clipboard_clear()
            self.clipboard_append(backend_code)

            messagebox.showinfo(
                "API Context Copied!",
                "The backend's API definition has been copied to your clipboard.\n\n"
                "How to use it:\n"
                "1. Paste this into your AI (ChatGPT, Gemini, etc.).\n"
                "2. Ask it to write a build script. For example: 'Using the provided API, write a blueprint to create a Node.js Express server.'\n"
                "3. Paste the AI's response (the script) into the main window here."
            )
            self._update_console_widget("Copied backend API context to clipboard.")
        except Exception as e:
            messagebox.showerror("Error", f"Could not copy the backend context: {e}")
            self._update_console_widget(f"Error copying context: {e}")

    # --- THE REST OF THE FILE IS UNCHANGED ---
    def process_log_queue(self):
        try:
            while True:
                message = self.log_queue.get_nowait()
                if message is None:
                    self.build_finished()
                else:
                    self._update_console_widget(message)
        except queue.Empty:
            pass
        self.after(100, self.process_log_queue)

    def run_the_builder(self):
        build_script = self.script_input.get("1.0", tk.END)
        if not build_script.strip():
            messagebox.showwarning("Input Missing", "Please paste a build script in the top text area.")
            return
        self.run_button.config(state="disabled")
        self.copy_context_button.config(state="disabled")
        self._clear_console()
        thread = threading.Thread(target=self._run_builder_in_background, args=(build_script,), daemon=True)
        thread.start()

    def _run_builder_in_background(self, script_content):
        try:
            cli_core.run_builder(script_content, self.log_queue.put)
        except cli_core.DependencyActionRequired as e:
            self.log_queue.put(f"⚠️ {e}")
            result_queue = queue.Queue()
            self.after(0, lambda: result_queue.put(self.show_dependency_dialog(e)))
            choice, command_to_run, cwd = result_queue.get()
            if choice == 'proceed':
                self.log_queue.put(f"User approved. Running: {command_to_run}")
                try:
                    proc = subprocess.Popen(command_to_run.split(), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding='utf-8', errors='replace', cwd=cwd)
                    for line in iter(proc.stdout.readline, ''): self.log_queue.put(line.strip())
                    self.log_queue.put("\nResuming build process...")
                    cli_core.run_builder(script_content, self.log_queue.put)
                except Exception as run_exc:
                    self.log_queue.put(f"--- ERROR during dependency installation: {run_exc} ---")
            else:
                self.log_queue.put("🛑 BUILD HALTED by user at dependency confirmation.")
        except cli_core.ToolMissingError as e:
            self.after(0, self.show_tool_missing_dialog, e)
            self.log_queue.put(f"🛑 BUILD HALTED: {e}")
        except Exception as e:
            self.log_queue.put(f"--- A critical error occurred in the backend thread: {e} ---")
        finally:
            self.log_queue.put(None)

    def build_finished(self):
        self._update_console_widget("\n✅ Build process finished or halted.")
        self.run_button.config(state="normal")
        self.copy_context_button.config(state="normal")

    def show_tool_missing_dialog(self, e: cli_core.ToolMissingError):
        dialog = tk.Toplevel(self)
        dialog.title("Missing Required Tool")
        message = f"{e}\n\nPlease install it to continue."
        tk.Label(dialog, text=message, pady=10, padx=10).pack()
        if e.command_to_run:
            cmd_frame = tk.LabelFrame(dialog, text="Suggested Command (run in your own terminal)", padx=5, pady=5)
            cmd_frame.pack(padx=10, pady=5, fill="x")
            cmd_text = tk.Entry(cmd_frame, relief="solid")
            cmd_text.insert(0, e.command_to_run)
            cmd_text.config(state="readonly")
            cmd_text.pack(side="left", fill="x", expand=True)
            def copy_command(): self.clipboard_clear(); self.clipboard_append(e.command_to_run); copy_btn.config(text="Copied!")
            copy_btn = tk.Button(cmd_frame, text="Copy", command=copy_command)
            copy_btn.pack(side="left", padx=(5,0))
        tk.Button(dialog, text="OK", command=dialog.destroy, width=10).pack(pady=10)
        dialog.transient(self); dialog.grab_set()

    def show_dependency_dialog(self, e: cli_core.DependencyActionRequired):
        dialog = tk.Toplevel(self)
        dialog.title("Dependency Action Required")
        user_choice = tk.StringVar(value='cancel')
        message = f"{e}\n\nThe following command needs to be run:"
        tk.Label(dialog, text=message, pady=10, padx=10).pack()
        cmd_frame = tk.LabelFrame(dialog, text="Command to Run", padx=5, pady=5)
        cmd_frame.pack(padx=10, pady=5, fill="x")
        cmd_text = tk.Entry(cmd_frame, relief="solid")
        cmd_text.insert(0, e.command_to_run)
        cmd_text.config(state="readonly")
        cmd_text.pack(side="left", fill="x", expand=True)
        def copy_command(): self.clipboard_clear(); self.clipboard_append(e.command_to_run); copy_btn.config(text="Copied!")
        copy_btn = tk.Button(cmd_frame, text="Copy", command=copy_command)
        copy_btn.pack(side="left", padx=(5,0))
        tk.Label(dialog, text="You can copy this command and run it in your own terminal, or click 'Proceed' to have the application run it for you.", wraplength=400, justify="left", padx=10).pack()
        btn_frame = tk.Frame(dialog); btn_frame.pack(pady=10)
        def on_proceed(): user_choice.set('proceed'); dialog.destroy()
        def on_cancel(): user_choice.set('cancel'); dialog.destroy()
        if not e.command_to_run.strip().startswith('sudo'):
            tk.Button(btn_frame, text="Proceed", command=on_proceed, bg="#4CAF50", fg="white").pack(side="left", padx=5)
        tk.Button(btn_frame, text="Cancel Build", command=on_cancel).pack(side="left", padx=5)
        dialog.transient(self); dialog.grab_set(); self.wait_window(dialog)
        return user_choice.get(), e.command_to_run, e.cwd

    def _clear_console(self):
        self.console_output.config(state='normal'); self.console_output.delete('1.0', tk.END); self.console_output.config(state='disabled')
    def _update_console_widget(self, message):
        self.console_output.config(state='normal'); self.console_output.insert(tk.END, message + '\n'); self.console_output.config(state='disabled'); self.console_output.see(tk.END)