# compiler.py
"""
This module contains all the dedicated logic for compiling source code.
It is designed to be a self-contained library of compiler functions,
decoupled from the main application's core logic.
"""

import os
import platform
import glob

def compile_source(
    language: str,
    source_files: list,
    output_name: str,
    # These are callbacks passed from cli_core to keep this module decoupled
    run_command_func: callable,
    require_tool_func: callable,
    output_callback_func: callable,
    # Optional compilation parameters
    output_type: str = 'executable',
    include_dirs: list = None,
    library_dirs: list = None,
    libraries: list = None,
    cwd: str = None
):
    """
    Translates a high-level compilation request into specific, platform-aware
    compiler commands. This is the main entry point for this module.
    """
    output_callback_func(f"\n--- [Compiler] Starting compilation for: {output_name} ({language}) ---")
    cmd = []
    
    # Use glob to expand wildcards like 'src/*.c'
    expanded_sources = []
    for s in source_files:
        glob_path = os.path.join(cwd, s) if cwd else s
        expanded_sources.extend(glob.glob(glob_path))
    
    if not expanded_sources:
        raise FileNotFoundError("Compiler error: No source files found for compilation.")

    language = language.lower()
    if language in ['c', 'cpp', 'c++']:
        compiler = "g++" if 'cpp' in language or 'c++' in language else "gcc"
        require_tool_func(compiler)
        
        # Determine the final output name with correct extension
        final_output_name = output_name
        if output_type == 'shared_library':
            if platform.system() == "Windows": final_output_name += ".dll"
            elif platform.system() == "Linux": final_output_name += ".so"
            elif platform.system() == "Darwin": final_output_name += ".dylib"
        elif platform.system() == "Windows" and output_type == 'executable':
            final_output_name += ".exe"

        cmd = [compiler] + expanded_sources + ["-o", final_output_name]
        
        if output_type == 'shared_library':
            cmd.append("-shared")
            if platform.system() != "Windows":
                 cmd.append("-fPIC") # Position-Independent Code for non-Windows shared libs
        elif output_type == 'static_library':
             raise NotImplementedError("Static library creation is complex and not yet supported.")
        
        # Add include and library paths
        if include_dirs: cmd.extend([f"-I{d}" for d in include_dirs])
        if library_dirs: cmd.extend([f"-L{d}" for d in library_dirs])
        if libraries: cmd.extend([f"-l{d}" for d in libraries])

        run_command_func(cmd, cwd=cwd)

    elif language == 'java':
        require_tool_func("javac")
        require_tool_func("jar")
        
        # Step 1: Compile .java to .class
        compile_cmd = ["javac"] + expanded_sources
        run_command_func(compile_cmd, cwd=cwd)

        if output_type == 'jar':
            # Assumes a Manifest.txt file was created by the blueprint
            if not os.path.exists(os.path.join(cwd, "Manifest.txt") if cwd else "Manifest.txt"):
                 raise FileNotFoundError("Compiler error: 'Manifest.txt' is required for creating an executable JAR but was not found.")
            
            class_files = [os.path.relpath(f, cwd).replace('.java', '.class') for f in expanded_sources]
            jar_cmd = ["jar", "cfm", f"{output_name}.jar", "Manifest.txt"] + class_files
            run_command_func(jar_cmd, cwd=cwd)
    
    else:
        raise ValueError(f"Compiler error: Unsupported language for compilation: '{language}'.")

    output_callback_func(f"✅ --- [Compiler] Compilation successful. ---")